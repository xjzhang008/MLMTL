function [Wp1 eta k] = MulttaskU(UU, X,Y,opts)


if ~exist('opts', 'var')
    opts = [];
end    
if isfield(opts, 'Omega');       Omega = opts.Omega;          end
if isfield(opts, 'beta');        beta = opts.beta;            end
if isfield(opts, 'm');           m = opts.m;                  end
if isfield(opts, 'tau');         tau = opts.tau;              end
if isfield(opts, 'itemax');      itemax = opts.itemax;        end
if isfield(opts, 'gamma');       gamma = opts.gamma;          end
if isfield(opts, 'tol');         tol = opts.tol;          end

[n1 n2 n3 n] = size(X);
absOme = sum(Omega(:));
II = eye(n3);

%% initial values
Wp = zeros([n1 n2 n3]);
Zp = zeros([n1 n2 n3]);
%%

for k = 1:itemax
    % compute T^{p+1}
    for i = 1:n1
        for j = 1:n2
            if Omega(i,j) == 1
               Xij = reshape(X(i,j,:,:),[n3 m]);
%               Tp1(i,j,:) = inv(Xij*Xij' + absOme*m*II)*(Xij*vectorize(Y(i,j,:)) + beta*absOme*m*(vectorize(Wp(i,j,:)) + vectorize(Zp(i,j,:))/beta)); 
               Tp1(i,j,:) = inv(Xij*Xij' + II)*(Xij*vectorize(Y(i,j,:)) + beta*(vectorize(Wp(i,j,:)) + vectorize(Zp(i,j,:))/beta)); 
            else
               Tp1(i,j,:) = Wp(i,j,:) + Zp(i,j,:)/beta;
            end
        end
    end 
    % compute W^{p+1}
    Wp1 = prox_utnn(UU,Tp1 - Zp./beta,gamma/beta);
    
    % update the multiplier Z^{p+1}
    
    Zp1 = Zp + tau*beta*(Wp1 - Tp1);
    
    %% stopping criterion
    if k >= 60
    SS = zeros([n1 n2 n3]);
    for i = 1:n1
        for j = 1:n2
            if Omega(i,j) == 1
                Xij = reshape(X(i,j,:,:),[n3 m]);
                SS(i,j,:) = Xij*Xij'*vectorize(Tp1(i,j,:)) - Xij*vectorize(Y(i,j,:)) - vectorize(Zp1(i,j,:));
            else
                SS(i,j,:) = -vectorize(Zp1(i,j,:));
            end
        end
    end
    eta1 = norm(SS(:))/(1 + norm(Zp1(:)) + norm(Tp1(:)));
    
    eta2 = Wp1 - prox_utnn(UU, Wp1 - Zp1,gamma);
    eta2 = norm(eta2(:))/(1 + norm(Wp1(:)) + norm(Zp1(:)));
    
    eta3 = norm(Wp1(:) - Tp1(:));
    eta3 = eta3/(1 + norm(Wp1(:)) + norm(Tp1(:)));
    
    eta = max([eta1 eta2 eta3]);
    if eta < tol
         break;
    end
   end
                
    
    %%
    Wp = Wp1;
    Tp = Tp1;
    Zp = Zp1;
    
end


end