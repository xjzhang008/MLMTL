function C = tprodU(UU,A,B)

% Tensor-tensor product of two 3 way tensors: C = A*B
% UU - unitary matrix
% A - n1*n2*n3 tensor
% B - n2*l*n3  tensor
% C - n1*l*n3  tensor
%
% version 2.0 - 09/10/2017
%
% Written by Canyi Lu (canyilu@gmail.com)
%
%
% References: 
% Canyi Lu, Tensor-Tensor Product Toolbox. Carnegie Mellon University. 
% June, 2018. https://github.com/canyilu/tproduct.
%
% Canyi Lu, Jiashi Feng, Yudong Chen, Wei Liu, Zhouchen Lin and Shuicheng
% Yan, Tensor Robust Principal Component Analysis with A New Tensor Nuclear
% Norm, arXiv preprint arXiv:1804.03728, 2018
%

[n1,n2,n3] = size(A);
[m1,m2,m3] = size(B);

if n2 ~= m1 || n3 ~= m3 
    error('Inner tensor dimensions must agree.');
end

O = tenmat(A,[3]); % unfolding 
SS = O.data;
YA = UU'*SS;
YA = tensor(tenmat(YA, O.rdims, O.cdims, O.tsize));
YA = YA.data;

O = tenmat(B,[3]); % unfolding 
SS = O.data;
YB = UU'*SS;
YB = tensor(tenmat(YB, O.rdims, O.cdims, O.tsize));
YB = YB.data;

C = zeros(n1,m2,n3);


for i = 1:n3
    C(:,:,i) = YA(:,:,i)*YB(:,:,i);
end

O = tenmat(C,[3]); %square norm
SS = O.data;
YC = UU*SS;
YC = tensor(tenmat(YC, O.rdims, O.cdims, O.tsize));
C = YC.data;

