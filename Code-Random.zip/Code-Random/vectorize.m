function Y = vectorize(X)

Y  = X(:);

end