clear all;
close all;

addpath('tensor_toolbox_2.6');
addpath('tproduct-master');

%% constructed a third-order tensor W
% n1 = 30;
% n2 = 30;
% n3 = 30;
% r1 = 15;
% r2 = 10;
% r3 = 20;

n1 = 30;
n2 = 20;
n3 = 25;
r = 8;



MSEfft = [];
MSE = [];
MSEU = [];

for kk = 1:10
fprintf('The %d-th trail\n',kk)

% Nway = [n1, n2, n3]; % dimension of tensor
% coreNway = [r1,r2,3];
% 
% % randomly generate core tensor
% G = tensor(randn(coreNway));
% A = cell(1,ndims(G));
% % randomly generate factor matrices
% for i = 1:ndims(G)
%     A{i} = randn(Nway(i),coreNway(i));
% end
% % generate tensor
% M = full(ttensor(G,A));
% % M = tensor(M.data/max(M.data(:)));
% N = ndims(M);
% W = M.data;


%% FFT
A = randn([n1 r n3]);
B = randn([r n2 n3]);
W1 = tprod(A,B);


%% DCT
A1 = randn([n1 r n3]);
B1 = randn([r n2 n3]);
W2 = tproddct(A1,B1);

%% U
A2 = randn([n1 r n3]);
B2 = randn([r n2 n3]);
UU = randn([n3 n3]);
UU = orth(UU);
W3 = tprodU(UU,A2,B2);

%% Construct Omega

sr = 1;
fprintf('Sampling ratio = %0.8e\n',sr);
temp = randperm(n1*n2);
kks = round((sr)*n1*n2);
Omega = zeros(n1,n2); 
Omega(temp(1:kks)) = 1;

%% train data
m = 70;  %% number of training data for wach task
X = randn([n1 n2 n3 m]);
Y1 = zeros([n1 n2 m]);
Y2 = zeros([n1 n2 m]);
Y3 = zeros([n1 n2 m]);

for i = 1:n1
    for j = 1:n2
        for k = 1:m
            Y1(i,j,k) = (vectorize(X(i,j,:,k)))'*vectorize(W1(i,j,:)) + 0.1*randn(1);
            Y2(i,j,k) = (vectorize(X(i,j,:,k)))'*vectorize(W2(i,j,:)) + 0.1*randn(1);
            Y3(i,j,k) = (vectorize(X(i,j,:,k)))'*vectorize(W3(i,j,:)) + 0.1*randn(1);
        end
    end
end



%% parameters

gamma = 10;
beta = 1;
tau = 1.618;
itemax = 200;
tol = 1e-3;

opts.tol = tol;
opts.gamma = gamma;
opts.itemax = itemax;   
opts.beta = beta;  
opts.m = m;
opts.tau = tau;
opts.Omega = Omega;

%% main loop

%% FFT

fprintf('FFT: \n');
tic;
[WpFFT eta0 kk0] = MulttaskFFT(X,Y1,opts);
toc;

%%
gamma = 3;
opts.gamma = gamma;

%% DCT
fprintf('DCT: \n');
tic;
[WpDCT eta kk] = MulttaskDCT(X,Y2,opts);
toc;

%% U

fprintf('Unitary transform: \n');
     O = tenmat(WpDCT,[3]); %square norm
     O = O.data;
     [U D V] = svd(O,'econ');
     clear D V
     
    tic;
     [WpU eta1 k1] = MulttaskU(UU, X,Y3,opts);
     toc;
     
     


%% validation
m1 = 20;
X = randn([n1 n2 n3 m1]);
Yv1 = zeros([n1 n2 m1]);
Yv2 = zeros([n1 n2 m1]);
Yv3 = zeros([n1 n2 m1]);

for i = 1:n1
    for j = 1:n2
        for k = 1:m1
            Yv1(i,j,k) = (vectorize(X(i,j,:,k)))'*vectorize(W1(i,j,:));
            Yv2(i,j,k) = (vectorize(X(i,j,:,k)))'*vectorize(W2(i,j,:));
            Yv3(i,j,k) = (vectorize(X(i,j,:,k)))'*vectorize(W3(i,j,:));
        end
    end
end

%% compute value
YcFFT = zeros([n1 n2 m1]);
for i = 1:n1
    for j = 1:n2
        for k = 1:m1
            YcFFT(i,j,k) = (vectorize(X(i,j,:,k)))'*vectorize(WpFFT(i,j,:));
        end
    end
end

%% MSE of FFT
MSE00 = norm(Yv1(:)-YcFFT(:))^2/(n1*n2*m1);
fprintf('FFT: MSE = %4.4f\n',MSE00);
MSEfft = [MSEfft; MSE00];

%% DCT
Yc = zeros([n1 n2 m1]);
for i = 1:n1
    for j = 1:n2
        for k = 1:m1
            Yc(i,j,k) = (vectorize(X(i,j,:,k)))'*vectorize(WpDCT(i,j,:));
        end
    end
end


%% MSE of DCT
MSE0 = norm(Yv2(:)-Yc(:))^2/(n1*n2*m1);
fprintf('DCT: MSE = %4.4f\n',MSE0);
MSE = [MSE; MSE0];

%% U
YcU = zeros([n1 n2 m1]);
for i = 1:n1
    for j = 1:n2
        for k = 1:m1
            YcU(i,j,k) = (vectorize(X(i,j,:,k)))'*vectorize(WpU(i,j,:));
        end
    end
end

%% MSE of U
MSE1 = norm(Yv3(:)-YcU(:))^2/(n1*n2*m1);
fprintf('U: MSE = %4.4f\n',MSE1);
MSEU = [MSEU; MSE1];

end

%% average MSE
AMSEfft = sum(MSEfft(:))/length(MSEfft);
fprintf('Average MSE = %0.4e\n',AMSEfft);

AMSE = sum(MSE(:))/length(MSE);
fprintf('Average MSE = %0.4e\n',AMSE);

AMSEU = sum(MSEU(:))/length(MSEU);
fprintf('Average MSE = %0.4e\n',AMSEU);


