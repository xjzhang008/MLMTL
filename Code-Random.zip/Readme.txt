%%
Xiongjun Zhang, Jin Wu, and Michael K. Ng. 
Multilinear Multitask Learning by Transformed Tensor Singular Value Decomposition, 
Machine Learning with Applications, 13:100479, 2023.
%%

We test the random tensors for 10 trails in this code.

Run Test.m for this experiments.

Please contact Xiongjun Zhang (Email: xjzhang@mail.ccnu.edu.cn) if you have any question.

We use two tensor toolboxes in the code:
tensor_toolbox_2.6 (now have beed updated): https://www.tensortoolbox.org/
t-product: https://github.com/canyilu/Tensor-tensor-product-toolbox